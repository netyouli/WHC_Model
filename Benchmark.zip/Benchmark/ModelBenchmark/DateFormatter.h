//
//  DateFormatter.h
//  ModelBenchmark
//
//  Created by ibireme on 15/9/18.
//  Copyright (c) 2015 ibireme. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DateFormatter : NSObject
+ (NSDateFormatter *)githubDataFormatter;
+ (NSDateFormatter *)weiboDataFormatter;
@end
